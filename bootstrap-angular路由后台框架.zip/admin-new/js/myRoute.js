var cloud = angular.module("cloud", ["ngRoute", "infinite-scroll"]);
//定义路由
function cloudCtrl($routeProvider) {
    $routeProvider
        .when("/", {
            controller: dynamicCtrl,
            templateUrl: 'dynamic.html'
        })
        .when("/project", {
            controller: projectCtrl,
            templateUrl: 'project.html'
        })
        .when("/user", {
            controller: userCtrl,
            templateUrl: 'user.html'
        })
        .when("/node", {
            controller: nodeCtrl,
            templateUrl: 'node.html'
        })
        .otherwise({
            redirectTo: "/"
        })
}

// 配置路由到angularjs
cloud.config(cloudCtrl);

// 定义控制器
function dynamicCtrl($scope, $http) {
    // 刚开始初始化第0页
    var j = 0;
    // 第0页数据为空
    var news = [];
    // 定义angularjs变量赋值为这个数组对象
    $scope.news = news;
    // 定义无限滚动追加代码
    $scope.loadMore = function() {
        // 每次滚动分页加1
        j = j + 1;
        // 调用一个分页显示几条数据
        var newsTwo = [
            {title: '1', content: '新闻内容 hello world', time: '2016', num: j},
            {title: '1', content: '新闻内容 hello world', time: '2016', num: j},
            {title: '1', content: '新闻内容 hello world', time: '2016', num: j}
        ];
        //获取最大分页数,如果小于这个页数那么滚动就不在追加
        if(j < 5) {
            for (var i = 0; i < newsTwo.length; i++) {
                $scope.news.push(newsTwo[i]);
            }
        }
    };
}

function projectCtrl($scope, $http) {

}
function userCtrl($scope, $http) {

}
function nodeCtrl($scope, $http) {

}