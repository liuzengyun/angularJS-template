// 首先引入依赖，和引入路由依赖一样
var beyond = angular.module("beyond", ["ngRoute", 'ngFileUpload']);

// 上传文件， 定义上传文件控制器
beyond.controller("fileCtrl", ['$scope', 'Upload', function ($scope, Upload) {
    $scope.fileInfo = $scope.file;

    $scope.submit = function () {
        $scope.upload($scope.file);
    }
    // 调用接口， 传递参数
    $scope.upload = function (file, type) {
        Upload.upload({
            url: url + 'excel/lawyer',
            data: {file: file, uid: uid}

            //成功的情况
        }).success(function (data, status, headers, config) {
            console.log(data);

            //失败的情况
        }).error(function (data) {
            console.log(data);
        })
    }

}]);